import Foundation

enum MountError: LocalizedError {
  case commandFailed(String)
  case adminCancelled

  var errorDescription: String? {
    switch self {
    case .commandFailed(let message):
      return message
    case .adminCancelled:
      return "Administrator permission was cancelled."
    }
  }
}

final class MountManager {
  static let shared = MountManager()

  private let ntfs3gPath = "/usr/local/bin/ntfs-3g"
  private let diskutilPath = "/usr/sbin/diskutil"

  private init() {}

  func mountReadWrite(drive: NTFSDrive) async throws -> String {
    let mountPoint = drive.preferredMountPoint
    let escapedMount = shellEscape(mountPoint)
    let escapedPartition = shellEscape(drive.deviceNode)
    let escapedWhole = shellEscape(drive.wholeDiskNode)
    let escapedNtfs = shellEscape(ntfs3gPath)
    let volumeName = shellEscape(drive.displayName)

    let script = """
    set -e
    USER_ID=$(/usr/bin/stat -f %u /dev/console)
    GROUP_ID=$(/usr/bin/stat -f %g /dev/console)
    \(shellEscape(diskutilPath)) unmountDisk \(escapedWhole) || true
    mkdir -p \(escapedMount)
    \(escapedNtfs) \(escapedPartition) \(escapedMount) \\
      -o volname=\(volumeName) \\
      -o local \\
      -o negative_vncache \\
      -o auto_xattr \\
      -o auto_cache \\
      -o noatime \\
      -o windows_names \\
      -o streams_interface=openxattr \\
      -o inherit \\
      -o uid="$USER_ID" \\
      -o gid="$GROUP_ID" \\
      -o allow_other \\
      -o big_writes
  """

    try runAsAdmin(script: script)
    return mountPoint
  }

  func remountReadOnly(drive: NTFSDrive) async throws {
    let escapedWhole = shellEscape(drive.wholeDiskNode)
    let mountPoint = drive.mountPoint ?? drive.preferredMountPoint
    let escapedMount = shellEscape(mountPoint)

    let script = """
    set -e
    \(shellEscape(diskutilPath)) unmount \(escapedMount) 2>/dev/null || umount \(escapedMount) 2>/dev/null || true
    \(shellEscape(diskutilPath)) mountDisk \(escapedWhole)
  """

    try runAsAdmin(script: script)
  }

  func runAsAdmin(script: String) throws {
    let escapedScript = script
      .replacingOccurrences(of: "\\", with: "\\\\")
      .replacingOccurrences(of: "\"", with: "\\\"")

    let osa = """
    do shell script "\(escapedScript)" with administrator privileges
    """

    let process = Process()
    process.executableURL = URL(fileURLWithPath: "/usr/bin/osascript")
    process.arguments = ["-e", osa]

    let pipe = Pipe()
    process.standardOutput = pipe
    process.standardError = pipe

    try process.run()
    process.waitUntilExit()

    let data = pipe.fileHandleForReading.readDataToEndOfFile()
    let output = String(data: data, encoding: .utf8) ?? ""

    if process.terminationStatus == 1 && output.lowercased().contains("user canceled") {
      throw MountError.adminCancelled
    }

    if process.terminationStatus != 0 {
      throw MountError.commandFailed(output.trimmingCharacters(in: .whitespacesAndNewlines))
    }
  }

  private func shellEscape(_ value: String) -> String {
    "'" + value.replacingOccurrences(of: "'", with: "'\\''") + "'"
  }
}
