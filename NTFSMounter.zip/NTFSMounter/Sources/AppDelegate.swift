import AppKit

@main
final class AppDelegate: NSObject, NSApplicationDelegate {
  private var statusItem: NSStatusItem!
  private var menu = NSMenu()
  private let driveMonitor = DriveMonitor()
  private var mainWindowController: MainWindowController!

  func applicationDidFinishLaunching(_ notification: Notification) {
    NSApp.setActivationPolicy(.regular)

    setupStatusItem()

    mainWindowController = MainWindowController(driveMonitor: driveMonitor)
    driveMonitor.onDrivesChanged = { [weak self] in
      self?.rebuildMenu()
      self?.mainWindowController.refreshDrives()
    }
    driveMonitor.start()
    rebuildMenu()
    presentMainWindow()
  }

  func applicationDidBecomeActive(_ notification: Notification) {
    if mainWindowController?.window?.isVisible != true {
      presentMainWindow()
    }
  }

  func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
    presentMainWindow()
    return true
  }

  private func presentMainWindow() {
    mainWindowController.showWindow(self)
    mainWindowController.window?.makeKeyAndOrderFront(nil)
    NSApp.activate(ignoringOtherApps: true)
  }

  private func setupStatusItem() {
    statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
    if let button = statusItem.button {
      button.title = "NTFS"
      if let image = NSImage(systemSymbolName: "externaldrive", accessibilityDescription: "NTFS Mounter") {
        image.isTemplate = true
        button.image = image
        button.imagePosition = .imageLeading
      }
      button.toolTip = "NTFS Mounter"
    }

    statusItem.menu = menu
  }

  private func rebuildMenu() {
    menu.removeAllItems()

    let header = NSMenuItem(title: "NTFS Mounter", action: nil, keyEquivalent: "")
    header.isEnabled = false
    menu.addItem(header)
    menu.addItem(.separator())

    let drives = driveMonitor.ntfsDrives
    if drives.isEmpty {
      let empty = NSMenuItem(title: "No NTFS drives detected", action: nil, keyEquivalent: "")
      empty.isEnabled = false
      menu.addItem(empty)
    } else {
      for drive in drives {
        addDriveItems(drive)
      }
    }

    menu.addItem(.separator())
    menu.addItem(NSMenuItem(title: "Open Window", action: #selector(showMainWindow), keyEquivalent: "w"))
    menu.addItem(NSMenuItem(title: "Refresh", action: #selector(refreshDrives), keyEquivalent: "r"))
    menu.addItem(NSMenuItem(title: "Quit", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q"))
  }

  private func addDriveItems(_ drive: NTFSDrive) {
    let title = NSMenuItem(
      title: "\(drive.displayName)  [\(drive.partition)]",
      action: nil,
      keyEquivalent: ""
    )
    title.isEnabled = false
    menu.addItem(title)

    if drive.isMountedReadWrite {
      let mode = NSMenuItem(
        title: "  Read+Write (ntfs-3g) — switch to read-only",
        action: #selector(switchToReadOnly(_:)),
        keyEquivalent: ""
      )
      mode.representedObject = drive
      mode.target = self
      menu.addItem(mode)

      if let mountPoint = drive.mountPoint {
        let pathItem = NSMenuItem(title: "  \(mountPoint)", action: nil, keyEquivalent: "")
        pathItem.isEnabled = false
        menu.addItem(pathItem)

        let open = NSMenuItem(title: "  Open in Finder", action: #selector(openInFinder(_:)), keyEquivalent: "")
        open.representedObject = mountPoint
        open.target = self
        menu.addItem(open)
      }
    } else {
      let mode = NSMenuItem(
        title: "  Read-only — switch to read+write",
        action: #selector(switchToReadWrite(_:)),
        keyEquivalent: ""
      )
      mode.representedObject = drive
      mode.target = self
      menu.addItem(mode)
    }

    menu.addItem(.separator())
  }

  @objc private func showMainWindow() {
    presentMainWindow()
  }

  @objc private func refreshDrives() {
    driveMonitor.refresh()
  }

  @objc private func switchToReadWrite(_ sender: NSMenuItem) {
    guard let drive = sender.representedObject as? NTFSDrive else { return }
    driveMonitor.mountReadWrite(drive: drive)
  }

  @objc private func switchToReadOnly(_ sender: NSMenuItem) {
    guard let drive = sender.representedObject as? NTFSDrive else { return }
    driveMonitor.unmountAndRemount(drive: drive)
  }

  @objc private func openInFinder(_ sender: NSMenuItem) {
    guard let path = sender.representedObject as? String else { return }
    NSWorkspace.shared.selectFile(nil, inFileViewerRootedAtPath: path)
  }
}
