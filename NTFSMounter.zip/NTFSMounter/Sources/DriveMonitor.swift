import AppKit
import DiskArbitration
import Foundation

private func diskAppearedCallback(_ disk: DADisk, _ context: UnsafeMutableRawPointer?) {
  guard let context else { return }
  let monitor = Unmanaged<DriveMonitor>.fromOpaque(context).takeUnretainedValue()
  monitor.refresh()
}

private func diskDisappearedCallback(_ disk: DADisk, _ context: UnsafeMutableRawPointer?) {
  guard let context else { return }
  let monitor = Unmanaged<DriveMonitor>.fromOpaque(context).takeUnretainedValue()
  monitor.refresh()
}

final class DriveMonitor {
  var onDrivesChanged: (() -> Void)?

  private(set) var ntfsDrives: [NTFSDrive] = []
  private var session: DASession?
  private let queue = DispatchQueue(label: "com.ntfsmounter.drivemonitor")
  private var refreshTimer: DispatchSourceTimer?

  func start() {
    session = DASessionCreate(kCFAllocatorDefault)
    guard let session else { return }

    DASessionSetDispatchQueue(session, queue)

    let context = Unmanaged.passUnretained(self).toOpaque()
    DARegisterDiskAppearedCallback(session, nil, diskAppearedCallback, context)
    DARegisterDiskDisappearedCallback(session, nil, diskDisappearedCallback, context)

    let timer = DispatchSource.makeTimerSource(queue: queue)
    timer.schedule(deadline: .now() + 1, repeating: 3)
    timer.setEventHandler { [weak self] in
      self?.refresh()
    }
    timer.resume()
    refreshTimer = timer

    refresh()
  }

  func refresh() {
    let drives = Self.scanNTFSDrives()
    ntfsDrives = drives
    DispatchQueue.main.async { [weak self] in
      self?.onDrivesChanged?()
    }
  }

  func mountReadWrite(drive: NTFSDrive) {
    Task {
      do {
        let mountPoint = try await MountManager.shared.mountReadWrite(drive: drive)
        await MainActor.run {
          self.showAlert(title: "Mounted Read+Write", message: "\(drive.displayName) is available at \(mountPoint)")
        }
      } catch {
        await MainActor.run {
          self.showAlert(title: "Mount Failed", message: error.localizedDescription)
        }
      }
      refresh()
    }
  }

  func unmountAndRemount(drive: NTFSDrive) {
    Task {
      do {
        try await MountManager.shared.remountReadOnly(drive: drive)
        await MainActor.run {
          self.showAlert(title: "Mounted Read-only", message: "\(drive.displayName) is back in macOS read-only mode.")
        }
      } catch {
        await MainActor.run {
          self.showAlert(title: "Remount Failed", message: error.localizedDescription)
        }
      }
      refresh()
    }
  }

  @objc func mountReadWriteAction(_ sender: NSButton) {
    guard let partition = sender.identifier?.rawValue,
          let drive = ntfsDrives.first(where: { $0.partition == partition })
    else { return }
    mountReadWrite(drive: drive)
  }

  @objc func unmountAndRemountAction(_ sender: NSButton) {
    guard let partition = sender.identifier?.rawValue,
          let drive = ntfsDrives.first(where: { $0.partition == partition })
    else { return }
    unmountAndRemount(drive: drive)
  }

  private func showAlert(title: String, message: String) {
    let alert = NSAlert()
    alert.messageText = title
    alert.informativeText = message
    alert.alertStyle = .informational
    alert.addButton(withTitle: "OK")
    alert.runModal()
  }

  private static func scanNTFSDrives() -> [NTFSDrive] {
    let output = runCommand("/usr/sbin/diskutil", arguments: ["list", "-plist"])
    guard
      let data = output.data(using: .utf8),
      let plist = try? PropertyListSerialization.propertyList(from: data, format: nil) as? [String: Any],
      let allDisks = plist["AllDisksAndPartitions"] as? [[String: Any]]
    else {
      return []
    }

    var drives: [NTFSDrive] = []
    let ntfs3gMounts = currentNtfs3gMounts()

    for disk in allDisks {
      let wholeDisk = disk["DeviceIdentifier"] as? String ?? ""
      guard !wholeDisk.isEmpty else { continue }

      let partitions = (disk["Partitions"] as? [[String: Any]]) ?? []
      for partition in partitions {
        guard
          let partitionID = partition["DeviceIdentifier"] as? String,
          let content = partition["Content"] as? String,
          content == "Microsoft Basic Data" || content.contains("NTFS")
        else {
          continue
        }

        let infoOutput = runCommand("/usr/sbin/diskutil", arguments: ["info", "-plist", partitionID])
        guard
          let infoData = infoOutput.data(using: .utf8),
          let info = try? PropertyListSerialization.propertyList(from: infoData, format: nil) as? [String: Any]
        else {
          continue
        }

        let fs = (info["FilesystemType"] as? String) ?? (info["FilesystemName"] as? String) ?? ""
        guard fs.uppercased().contains("NTFS") else { continue }

        let label = (info["VolumeName"] as? String) ?? (partition["VolumeName"] as? String) ?? wholeDisk
        let mountPoint = info["MountPoint"] as? String
        let rwMount = ntfs3gMounts[partitionID]

        drives.append(
          NTFSDrive(
            wholeDisk: wholeDisk,
            partition: partitionID,
            label: label,
            mountPoint: rwMount ?? mountPoint,
            isMountedReadWrite: rwMount != nil
          )
        )
      }
    }

    return drives.sorted { $0.displayName.localizedCaseInsensitiveCompare($1.displayName) == .orderedAscending }
  }

  private static func currentNtfs3gMounts() -> [String: String] {
    let output = runCommand("/sbin/mount", arguments: [])
    var result: [String: String] = [:]

    for line in output.split(separator: "\n") {
      guard line.contains("ntfs-3g") else { continue }
      let parts = line.split(separator: " ", omittingEmptySubsequences: true)
      guard parts.count >= 3 else { continue }

      let device = String(parts[0]).replacingOccurrences(of: "/dev/", with: "")
      let mountPoint = String(parts[2])
      result[device] = mountPoint
    }

    return result
  }

  private static func runCommand(_ launchPath: String, arguments: [String]) -> String {
    let process = Process()
    process.executableURL = URL(fileURLWithPath: launchPath)
    process.arguments = arguments

    let pipe = Pipe()
    process.standardOutput = pipe
    process.standardError = pipe

    do {
      try process.run()
      process.waitUntilExit()
    } catch {
      return ""
    }

    let data = pipe.fileHandleForReading.readDataToEndOfFile()
    return String(data: data, encoding: .utf8) ?? ""
  }
}
