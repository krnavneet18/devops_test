import AppKit

final class MainWindowController: NSWindowController {
  private let driveMonitor: DriveMonitor
  private let scrollView = NSScrollView()
  private let stackView = NSStackView()
  private let statusLabel = NSTextField(labelWithString: "Scanning for NTFS drives...")
  private var driveRows: [DriveRowView] = []

  init(driveMonitor: DriveMonitor) {
    self.driveMonitor = driveMonitor

    let window = NSWindow(
      contentRect: NSRect(x: 0, y: 0, width: 520, height: 360),
      styleMask: [.titled, .closable, .miniaturizable],
      backing: .buffered,
      defer: false
    )
    window.title = "NTFS Mounter"
    window.center()
    window.isReleasedWhenClosed = false
    window.isExcludedFromWindowsMenu = false
    window.collectionBehavior = [.moveToActiveSpace, .managed]

    super.init(window: window)
    setupUI()
    refreshDrives()
  }

  @available(*, unavailable)
  required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }

  private func setupUI() {
    guard let contentView = window?.contentView else { return }

    let header = NSTextField(wrappingLabelWithString:
      "Plug in an NTFS drive, then switch between read-only and read+write mode."
    )
    header.font = .systemFont(ofSize: 13)
    header.textColor = .secondaryLabelColor

    statusLabel.font = .boldSystemFont(ofSize: 12)

    let refreshButton = NSButton(title: "Refresh", target: self, action: #selector(refreshClicked))
    refreshButton.bezelStyle = .rounded

    let topBar = NSStackView(views: [statusLabel, NSView(), refreshButton])
    topBar.orientation = .horizontal
    topBar.alignment = .centerY

    stackView.orientation = .vertical
    stackView.alignment = .leading
    stackView.spacing = 10
    stackView.translatesAutoresizingMaskIntoConstraints = false

    scrollView.documentView = stackView
    scrollView.hasVerticalScroller = true
    scrollView.translatesAutoresizingMaskIntoConstraints = false

    let root = NSStackView(views: [header, topBar, scrollView])
    root.orientation = .vertical
    root.alignment = .leading
    root.spacing = 12
    root.edgeInsets = NSEdgeInsets(top: 16, left: 16, bottom: 16, right: 16)
    root.translatesAutoresizingMaskIntoConstraints = false

    contentView.addSubview(root)
    NSLayoutConstraint.activate([
      root.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
      root.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
      root.topAnchor.constraint(equalTo: contentView.topAnchor),
      root.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
      scrollView.widthAnchor.constraint(equalTo: root.widthAnchor, constant: -32),
      scrollView.heightAnchor.constraint(greaterThanOrEqualToConstant: 220),
    ])
  }

  func refreshDrives() {
    for row in driveRows {
      row.container.removeFromSuperview()
    }
    driveRows.removeAll()

    let drives = driveMonitor.ntfsDrives
    statusLabel.stringValue = drives.isEmpty
      ? "No NTFS drives detected"
      : "\(drives.count) NTFS drive(s) found"

    if drives.isEmpty {
      let empty = NSTextField(wrappingLabelWithString:
        "No NTFS drive is connected right now.\n\nConnect your NTFS external drive, then click Refresh."
      )
      empty.textColor = .secondaryLabelColor
      stackView.addArrangedSubview(empty)
      driveRows.append(DriveRowView(container: empty))
      return
    }

    for drive in drives {
      let row = DriveRowView(drive: drive, monitor: driveMonitor)
      stackView.addArrangedSubview(row.container)
      driveRows.append(row)
    }
  }

  @objc static func openFinderPath(_ sender: NSButton) {
    guard let path = sender.identifier?.rawValue else { return }
    NSWorkspace.shared.selectFile(nil, inFileViewerRootedAtPath: path)
  }

  @objc private func refreshClicked() {
    driveMonitor.refresh()
    refreshDrives()
  }
}

private final class DriveRowView {
  let container: NSView

  init(container: NSView) {
    self.container = container
  }

  init(drive: NTFSDrive, monitor: DriveMonitor) {
    let title = NSTextField(labelWithString: drive.displayName)
    title.font = .boldSystemFont(ofSize: 14)

    let details = NSTextField(labelWithString: "\(drive.partition) • \(drive.deviceNode)")
    details.textColor = .secondaryLabelColor
    details.font = .systemFont(ofSize: 12)

    let mode = drive.isMountedReadWrite ? "Read+Write (ntfs-3g)" : "Read-only (macOS)"
    let modeLabel = NSTextField(labelWithString: "Mode: \(mode)")
    modeLabel.font = .systemFont(ofSize: 12)

    let actionButton = NSButton()
    if drive.isMountedReadWrite {
      actionButton.title = "Switch to Read-only"
      actionButton.target = monitor
      actionButton.action = #selector(DriveMonitor.unmountAndRemountAction(_:))
    } else {
      actionButton.title = "Switch to Read+Write"
      actionButton.target = monitor
      actionButton.action = #selector(DriveMonitor.mountReadWriteAction(_:))
    }
    actionButton.bezelStyle = .rounded
    actionButton.identifier = NSUserInterfaceItemIdentifier(drive.partition)

    var extraViews: [NSView] = []
    if let mountPoint = drive.mountPoint {
      let path = NSTextField(labelWithString: "Mounted at: \(mountPoint)")
      path.font = .systemFont(ofSize: 11)
      path.textColor = .secondaryLabelColor
      extraViews.append(path)

      let openButton = NSButton(title: "Open in Finder", target: nil, action: #selector(MainWindowController.openFinderPath(_:)))
      openButton.bezelStyle = .rounded
      openButton.identifier = NSUserInterfaceItemIdentifier(mountPoint)
      extraViews.append(openButton)
    }

    let infoStack = NSStackView(views: [title, details, modeLabel] + extraViews)
    infoStack.orientation = .vertical
    infoStack.alignment = .leading
    infoStack.spacing = 4

    let row = NSStackView(views: [infoStack, actionButton])
    row.orientation = .horizontal
    row.alignment = .top
    row.spacing = 12
    row.edgeInsets = NSEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)

    let box = NSBox()
    box.boxType = .custom
    box.fillColor = NSColor.controlBackgroundColor
    box.cornerRadius = 8
    box.translatesAutoresizingMaskIntoConstraints = false
    box.addSubview(row)
    row.translatesAutoresizingMaskIntoConstraints = false
    NSLayoutConstraint.activate([
      row.leadingAnchor.constraint(equalTo: box.leadingAnchor),
      row.trailingAnchor.constraint(equalTo: box.trailingAnchor),
      row.topAnchor.constraint(equalTo: box.topAnchor),
      row.bottomAnchor.constraint(equalTo: box.bottomAnchor),
      box.widthAnchor.constraint(equalToConstant: 470),
    ])

    container = box
  }
}
