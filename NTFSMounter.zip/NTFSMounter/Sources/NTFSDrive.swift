import Foundation

final class NTFSDrive: NSObject {
    let wholeDisk: String
    let partition: String
    let label: String
  var mountPoint: String?
  var isMountedReadWrite: Bool

  init(wholeDisk: String, partition: String, label: String, mountPoint: String?, isMountedReadWrite: Bool) {
    self.wholeDisk = wholeDisk
    self.partition = partition
    self.label = label
    self.mountPoint = mountPoint
    self.isMountedReadWrite = isMountedReadWrite
  }

  var deviceNode: String { "/dev/\(partition)" }
  var wholeDiskNode: String { "/dev/\(wholeDisk)" }

  var preferredMountPoint: String {
    let safe = label
      .replacingOccurrences(of: "/", with: "-")
      .replacingOccurrences(of: ":", with: "-")
      .trimmingCharacters(in: .whitespacesAndNewlines)
    let name = safe.isEmpty ? partition : safe
    return "/Volumes/NTFS_\(name)"
  }

  var displayName: String {
    label.isEmpty ? partition : label
  }
}
