#!/bin/bash
set -euo pipefail

APP_NAME="NTFS Mounter"

if [[ "${1:-}" == "--restart" ]]; then
  killall NTFSMounter 2>/dev/null || true
  sleep 1
elif pgrep -xq NTFSMounter; then
  open -a "$APP_NAME"
  echo "$APP_NAME is already running — brought window to front."
  exit 0
fi

open -a "$APP_NAME"
echo "Started $APP_NAME — a window should appear on your desktop."
