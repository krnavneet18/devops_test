#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP_NAME="NTFS Mounter"
BUNDLE_DIR="$ROOT/build/$APP_NAME.app"
CONTENTS_DIR="$BUNDLE_DIR/Contents"
MACOS_DIR="$CONTENTS_DIR/MacOS"
RESOURCES_DIR="$CONTENTS_DIR/Resources"

rm -rf "$BUNDLE_DIR"
mkdir -p "$MACOS_DIR" "$RESOURCES_DIR"

swiftc \
  -O \
  -framework AppKit \
  -framework DiskArbitration \
  -framework Foundation \
  -o "$MACOS_DIR/NTFSMounter" \
  "$ROOT/Sources/NTFSDrive.swift" \
  "$ROOT/Sources/MountManager.swift" \
  "$ROOT/Sources/DriveMonitor.swift" \
  "$ROOT/Sources/MainWindowController.swift" \
  "$ROOT/Sources/AppDelegate.swift"

cp "$ROOT/Resources/Info.plist" "$CONTENTS_DIR/Info.plist"

echo "Built: $BUNDLE_DIR"
