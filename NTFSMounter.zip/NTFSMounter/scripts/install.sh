#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP_NAME="NTFS Mounter"
APP_SRC="$ROOT/build/$APP_NAME.app"
APP_DEST="/Applications/$APP_NAME.app"
FUSE_CONF="/etc/fuse.conf"

"$ROOT/scripts/build.sh"

echo "Installing app to $APP_DEST"
sudo rm -rf "$APP_DEST"
sudo cp -R "$APP_SRC" "$APP_DEST"

if [[ -f "$FUSE_CONF" ]]; then
  if ! grep -q '^user_allow_other' "$FUSE_CONF"; then
    echo "Enabling user_allow_other in $FUSE_CONF"
    sudo sed -i '' 's/^#user_allow_other/user_allow_other/' "$FUSE_CONF" 2>/dev/null || \
      echo 'user_allow_other' | sudo tee -a "$FUSE_CONF" >/dev/null
  fi
else
  echo "Creating $FUSE_CONF with user_allow_other"
  echo 'user_allow_other' | sudo tee "$FUSE_CONF" >/dev/null
fi

LAUNCH_AGENT="$HOME/Library/LaunchAgents/com.ntfsmounter.app.plist"
mkdir -p "$HOME/Library/LaunchAgents"

cat > "$LAUNCH_AGENT" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>com.ntfsmounter.app</string>
  <key>ProgramArguments</key>
  <array>
    <string>/usr/bin/open</string>
    <string>-a</string>
    <string>$APP_NAME</string>
  </array>
  <key>RunAtLoad</key>
  <true/>
  <key>LimitLoadToSessionType</key>
  <string>Aqua</string>
</dict>
</plist>
EOF

launchctl bootout "gui/$(id -u)" "$LAUNCH_AGENT" 2>/dev/null || true
launchctl bootstrap "gui/$(id -u)" "$LAUNCH_AGENT"

open -a "$APP_NAME"

echo ""
echo "Installed successfully."
echo "NTFS Mounter window should open on your desktop."
echo "You can also click the NTFS icon in the menu bar (top-right) or the Dock icon."
echo "It will start automatically on login."
