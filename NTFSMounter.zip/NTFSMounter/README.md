# NTFS Mounter

Menu bar app for macOS 12+ that detects NTFS drives and lets you switch between:

- **Read-only** (macOS default mount)
- **Read+Write** (`ntfs-3g` via macFUSE)

## Why this fixes your issues

1. **Unique mount points** — each drive mounts to `/Volumes/NTFS_<DriveName>` instead of a fixed `/Volumes/NTFS`, avoiding stale mounts and missing files.
2. **Full disk unmount before ntfs-3g** — uses `diskutil unmountDisk` so macOS releases the volume completely.
3. **Finder copy error 100102** — uses the same mount flags as the official `ntfs-3g-mac` `mount_ntfs` helper (`auto_xattr`, `windows_names`, `streams_interface=openxattr`, `big_writes`, etc.), which avoids macOS metadata writes that NTFS cannot handle.

## Requirements

- macOS 12.7.6 or later
- [macFUSE](https://osxfuse.github.io/)
- `ntfs-3g` at `/usr/local/bin/ntfs-3g`

## Install

```bash
cd /Users/ansh/Project/NTFSMounter
chmod +x scripts/build.sh scripts/install.sh
./scripts/install.sh
```

The install script will:

1. Build the app
2. Copy it to `/Applications/NTFS Mounter.app`
3. Enable `user_allow_other` in `/etc/fuse.conf` (needed for `allow_other`)
4. Register a LaunchAgent so the menu bar app starts on login

## Usage

1. Plug in your NTFS drive.
2. Click the **external drive** icon in the menu bar.
3. Choose **switch to read+write** for your drive.
4. Enter your admin password when prompted.
5. Open the drive from the menu or Finder at `/Volumes/NTFS_<DriveName>`.

To go back to read-only, choose **switch to read-only** in the menu.

## Build only

```bash
./scripts/build.sh
open "build/NTFS Mounter.app"
```

## Notes

- Large media copies work best when copied via Finder or `cp` after read+write mount.
- If a drive was previously mounted manually at `/Volumes/NTFS`, eject it first.
- The app asks for admin rights only when mounting or remounting.
